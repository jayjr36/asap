package com.asapdelivery.asap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
